package com.shaafshah.jmenus;

import javax.swing.JButton;

public class TestCmd2 extends JButton implements Command{

	public TestCmd2() {
		super("Test");
		OneListener.getInstance().addCommand(this);
	}

	@Override
	public void execute() {
		System.out.println("HelloWorld");
	}
}
