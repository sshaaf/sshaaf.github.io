package com.shaafshah.jmenus;

import javax.swing.JMenuItem;

public class TestCmd extends JMenuItem implements Command{

	public TestCmd() {
		super("Test");
		OneListener.getInstance().addCommand(this);
	}

	@Override
	public void execute() {
		System.out.println("HelloWorld");
	}
}
