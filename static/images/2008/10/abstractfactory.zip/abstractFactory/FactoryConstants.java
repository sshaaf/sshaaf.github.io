public interface FactoryConstants {

	public int A = 1;
	public int B = 2;
	
}


