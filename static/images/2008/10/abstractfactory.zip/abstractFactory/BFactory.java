public class BFactory extends ComputerFactory {
	
	
	public String getName(){
		return "B";
	}
	
	public Product[] getProducts(){
		return null;
	}

	public Product getProduct(int productID){
		return null;
	}

}