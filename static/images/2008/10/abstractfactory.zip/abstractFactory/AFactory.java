public class AFactory extends ComputerFactory {
	
	
	public String getName(){
		return "A";
	}
	
	public Product[] getProducts(){
		return null;
	}

	public Product getProduct(int productID){
		return null;
	}

}