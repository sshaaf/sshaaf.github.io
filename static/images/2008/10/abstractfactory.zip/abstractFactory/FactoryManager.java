public class FactoryManager{

	private static FactoryManager factoryManager = null;

	private FactoryManager(){

	}

	
	public static FactoryManager getInstance(){
		if(factoryManager != null){
			return factoryManager;
		}
		else return factoryManager = new FactoryManager();
	}


	public ComputerFactory getFactory(int factory) throws IllegalArgumentException{

		switch(factory){
			case FactoryConstants.A:
			return new IBMFactory();

			case FactoryConstants.B:
			return new SUNFactory();

			default:
			throw new IllegalArgumentException("Sorry you hit the wrong factory, we closed down in 1600 BC");
		}
			
	}

	public static void main(String args[]){

		System.out.println(FactoryManager.getInstance().getFactory(FactoryConstants.A).getName());
		System.out.println(FactoryManager.getInstance().getFactory(FactoryConstants.B).getName());
		System.out.println(FactoryManager.getInstance().getFactory(3).getName());

	}

}


