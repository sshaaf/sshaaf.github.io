package com.shaafshah.jmenus;

import java.awt.FlowLayout;

import javax.swing.JFrame;

public class TestCode extends JFrame{

	public TestCode() {
		super("Test Frame");
		this.setSize(200,200);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
		this.setLayout(new FlowLayout());
		this.getContentPane().add(new TestCmd());
		this.getContentPane().add(new TestCmd2());
		
	}

	public static void main(String args[]){
		new TestCode();
		
	}
	
}
