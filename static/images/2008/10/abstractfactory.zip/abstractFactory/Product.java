public abstract class Product{
	
	public abstract String getName();	

	public abstract Specification getSpecification();

}