import java.util.Collection;


public abstract class Specification{

	public abstract Collection getSpecification();
	
}