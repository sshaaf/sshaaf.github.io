package com.shaafshah.jmenus;

public interface Command {

	public void execute();
	
}
