package com.shaafshah.jmenus;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.AbstractButton;

public class OneListener implements ActionListener{

	private static OneListener oneListener = null;
	
	private ArrayList<Command> commandList = null;
	
	private OneListener(){
		commandList = new ArrayList<Command>();
	}
	
	public static OneListener getInstance(){
		if(oneListener != null)	
			return oneListener;
		else return oneListener = new OneListener();
	}
	
	public void addCommand(Command command){
			commandList.add(command);
		    ((AbstractButton)command).addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		((Command)e.getSource()).execute();
	}
	
}
