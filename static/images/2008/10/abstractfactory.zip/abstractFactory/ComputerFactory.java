public abstract class ComputerFactory {

	public abstract String getName();

	public abstract Product[] getProducts();
	
	public abstract Product getProduct(int ProductID);

}


